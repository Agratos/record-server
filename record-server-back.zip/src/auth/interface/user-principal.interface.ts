export interface UserPrincipal {
  readonly username: string;
  readonly id: string;
  readonly email: string;
}
