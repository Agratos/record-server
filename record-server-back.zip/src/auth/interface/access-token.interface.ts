export interface AccessToken {
  readonly access_token: string;
}
