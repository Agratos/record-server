export enum RoleType {
  SENIOR = 1,
  MIDDLE = 2,
  JUNIOR = 3,
}
