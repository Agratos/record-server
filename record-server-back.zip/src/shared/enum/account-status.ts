export enum AccountStatus {
  INVALID = 0,
  VALID = 1,
}
