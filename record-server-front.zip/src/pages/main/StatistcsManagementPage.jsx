import React from 'react';
import styled from 'styled-components';

import StatisticsManagementSearch from 'components/search/StatisticsManagementSearch';

const StatistcsManagementPage = () => {
    
    return (
        <Wrapper>
            <StatisticsManagementSearch />
        </Wrapper>
    )
}
const Wrapper = styled.div`
`;


export default StatistcsManagementPage;