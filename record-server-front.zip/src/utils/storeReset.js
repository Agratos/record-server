export default {
    clear: () => {
        localStorage.clear();
        sessionStorage.clear();
    }
};